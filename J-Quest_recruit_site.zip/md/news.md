Check out my markdown!

We can even embed elements without fear of the HTML parser mucking up their
textual representation:

```html
<awesome-sauce>
  <div>Oops, I'm about to forget to close this div.
</awesome-sauce>
```